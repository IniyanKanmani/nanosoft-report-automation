msg = 'Hello World from Python'

print(msg)
